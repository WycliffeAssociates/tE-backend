#!/bin/sh

cd ~/TranslationExchange
exec docker-compose up
